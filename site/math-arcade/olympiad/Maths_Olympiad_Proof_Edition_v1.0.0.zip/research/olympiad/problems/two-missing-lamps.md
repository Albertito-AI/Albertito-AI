# The Two Missing Lamps

**Combinatorics · Summit · Untimed**

An eight-lamp cube can tilt through many coordinates at once. How tightly must the lit lamps cluster to contain the most cubes?

[Try this problem](https://alberttansinhon.com/math-arcade/olympiad/#two-missing-lamps) · [Play on GitHub Pages](https://albertito-ai.github.io/Albertito-AI/math-arcade/olympiad/#two-missing-lamps) · [Proof collection](../README.md)

## Problem

Let n ≥ k ≥ 4 be integers. Every binary string of length n represents a lamp. Add two strings coordinate by coordinate modulo 2. Exactly 2ᵏ − 2 of the lamps are lit, and S is their set.

An affine j-flat is a set of the form {a + ε₁v₁ + ⋯ + εⱼvⱼ : each εᵢ is 0 or 1}, where the 2ʲ choices give distinct points. An intact cube is an affine 3-flat with all eight lamps lit. Count each eight-point set once, whatever its base point or generating directions.

Determine the largest possible number of intact cubes as a function of k and n. Prove the bound, exhibit a configuration attaining it, and characterise every configuration attaining it.

## Staged hints

1. Start with four lamps. A four-point plane is two disjoint pairs having the same difference v. In how many directions does a given plane get counted?

2. For a set B, the directions v satisfying B + v = B are its periods. If |B| is twice an odd number, ask how many nonzero periods can coexist. For an odd set with one lamp unpaired in direction v, sum all its points modulo 2 to locate the unpaired lamp.

3. For each nonzero v, identify x with x + v. Mark a quotient point only when both original lamps are lit. A cube whose direction space contains v projects to a four-point plane in these marked quotient points.

4. Write h = 2ᵏ / 2. Separate quotient sets of sizes h − 1 and h − 2. For all smaller sizes r, count triples to bound the number of planes per point. Finally sum over directions. Each original pair of lit lamps contributes to exactly one quotient size.

## Checkpoints and answers

### Checkpoint 1

Suppose 30 lamps are lit. What is the greatest possible number of nonzero directions v for which adding v pairs off all 30 lamps?

**Answer.** 1

Two distinct nonzero periods u and v would partition S into four-point sets {x, x + u, x + v, x + u + v}. Four does not divide 30. Fifteen parallel pairs realise one period.

### Checkpoint 2

In a 16-point affine 4-flat, remove two points. How many four-point affine 2-flats survive?

**Answer.** 77

There are 140 planes originally. Each deleted point lies in 35, and seven planes contain both. Inclusion–exclusion gives 140 − 70 + 7 = 77. The seven through both correspond to the seven nonzero directions after quotienting by the line joining the two points.

### Checkpoint 3

With n = 8 and k = 5, what is the maximum number of intact eight-point cubes?

**Answer.** 345

For q = 32 the sharp formula gives (30 × 28 × 24 × 23) / 1344 = 345. Five dimensions suffice for the construction.

## Worked proof

### 1. The target and its local count

Put q = 2ᵏ and h = q/2. The maximum is (q − 2)(q − 4)(q − 8)(q − 9)/1344. Its maximisers are exactly the affine k-flats with any two distinct points removed. To prove this, let P(B) count four-point planes in any binary point set B. For nonzero v let a(v) count unordered pairs {x, x + v} in B. Then ∑a(v) = C(|B|, 2), where C denotes a binomial coefficient. Two different pairs of difference v form a plane. Each plane has exactly three nonzero directions, so 3P(B) = ∑ C(a(v), 2). All sums over directions below exclude zero.

### 2. A nearly full odd set

Take |B| = h − 1 and put R = (h − 2)/2. At most R disjoint pairs can have any one difference. For 0 ≤ a ≤ R, C(a, 2) ≤ a(R − 1)/2, with equality only at 0 or R. The pair count gives P(B) ≤ (h − 1)(h − 2)(h − 4)/24. A flat of size h with one point removed attains this bound, since every direction within the flat leaves exactly one unpaired point.

### 3. Recover the missing point from the odd set

Suppose the odd-set bound is attained and let c be the sum of all points of B. In every direction v occurring as a difference there are R pairs and one unmatched point u. Each pair sums to v and R = h/2 − 1 is odd. Thus c = u + v. In particular c lies outside B, since otherwise u would have a partner. The set B ∪ {c} is now invariant under every occurring difference. Let W be their linear span and fix b in B. All points of B lie in b + W, and so does c = u + v. Conversely invariance under the generating differences puts every point of b + W in B ∪ {c}. This proves that equality forces a flat of size h with one point removed.

### 4. The even set can have only one perfect pairing

Now let |B| = r = h − 2 and R = r/2. A direction with a(v) = R translates all of B onto itself. Two such directions u and v would partition B into four-point planes parallel to {0, u, v, u + v}, impossible since r is 2 modulo 4. In every other direction a(v) ≤ R − 1, so C(a(v), 2) ≤ a(v)(R − 2)/2. The one possible perfect direction adds at most R/2 to this sum-bound. Hence 3P(B) ≤ (R − 2)C(r, 2)/2 + R/2, giving P(B) ≤ r(h − 4)(h − 5)/24. Remove two points x and y from a flat of size h. Their difference gives R pairs, every other direction in the flat gives R − 1, and outside directions give zero. This attains the bound.

### 5. Price the planes in a quotient

Put A = (h − 4)(h − 5)/24 and D = (h − 2)(h − 4)/24. For any r ≤ h − 3, three distinct points determine the unique four-point plane completed by their sum. Each plane contains four triples, so P(B) ≤ C(r, 3)/4 ≤ Ar. The last inequality follows from (r − 1)(r − 2) ≤ (h − 4)(h − 5) for r ≥ 3; smaller sets have no plane. The even-set bound extends P(B) ≤ Ar to r = h − 2. For r = h − 1 the odd-set bound is instead P(B) ≤ Dr, with D − A = (h − 4)/8 > 0.

### 6. Count eight-point cubes through each direction

For nonzero v, the quotient identifies each pair {x, x + v} as one point, with addition inherited from the original space. Let Bᵥ consist of quotient points with both lamps lit and put rᵥ = |Bᵥ|. A four-point plane in Bᵥ lifts to one eight-point cube, and every cube with v among its directions arises this way. Each cube has seven nonzero directions. Thus 7 times the cube count equals ∑P(Bᵥ). Also ∑rᵥ = C(2h − 2, 2). Each rᵥ is at most h − 1, and equality means v is a period of S. As |S| is 2 modulo 4, at most one v earns the larger rate D. Consequently 7 times the cube count is at most A C(2h − 2, 2) + (D − A)(h − 1). Expanding and dividing by seven gives the claimed formula.

### 7. Attainment and rigidity

Take a k-flat and delete x and y. In direction x + y its projected marked set is a flat of size h missing one point. In every other nonzero direction parallel to the k-flat the projected set is a flat of size h missing two points. In all remaining directions it is empty. Each bound used in the sum is attained. Conversely, equality requires the positive premium (D − A)(h − 1) and equality in its odd-set bound. Hence some period v pairs all of S, and Bᵥ is a flat of size h missing one point. The inverse image of that whole flat is a k-flat of size 2h. The sole missing quotient point lifts to a missing pair. All other lamps in this k-flat belong to S.

## Proof rubric

- 1 point for the common-difference pair count for four-point planes and the sharp construction.

- 2 points for the odd-set plane bound and the equality proof that recovers the missing point.

- 2 points for the even-set bound, the single-period obstruction and the uniform bound for all smaller quotient sizes.

- 2 points for the seven-direction quotient count, the sharp maximum and the classification of every maximiser.

## Transfer exercise

In the 64-point binary space of dimension 6, exactly 30 lamps are lit. How many distinct lighting patterns attain the maximum?

**Answer.** 62496

Each pattern occupies a unique affine 5-flat. Distinct 5-flats meet in at most 16 points, whereas the pattern contains 30. There are 63 nonzero binary linear functionals, each with two level sets, giving 126 affine 5-flats. Distinct nonzero functionals have distinct kernels over the binary field. Choose the two missing points in C(32, 2) = 496 ways. The product is 62,496.

## Application: Which fourteen switch tests should the lab run?

A prototype has five on/off switches A through E. The lab can run 14 of 32 settings. It wants complete eight-run experiments in which three independent toggle actions can each be on or off. An action may flip several switches together. Count each distinct eight-setting experiment once.

**Decision question.** Schedule I runs every setting with E off except 00000 and 11110, writing switches in ABCDE order. Schedule II replaces 00110 in that list with 00111. Which schedule preserves more complete experiments? Does the winner ever exercise switch E in its on position?

### Worked model

Schedule I attains the theorem’s maximum of seven. Within the 16 settings with E off, each eight-run experiment is one parity condition on A through D. To avoid both omitted settings, the parity must agree on them and we choose the opposite value. Seven nonempty subsets of the four switches have even size, giving seven such conditions.

Schedule II leaves three settings missing from the E-off group. To exclude all three, a nonempty subset must have even size and contain either both C and D or neither. Exactly three qualify: AB, CD and ABCD. The single E-on setting cannot complete another experiment, since any affine cube on which E varies has four settings of each kind. Schedule II therefore preserves three experiments.

**Model limits.** A count of complete experiments measures this particular design objective. Schedule I never turns E on, so a fault that occurs only with E on can escape all fourteen tests.

**Try the model.** List both schedules in a spreadsheet and model a warning that appears exactly when E is on and A is off. Run both lists and count the warnings. Compare that observation with the seven-versus-three prediction, then choose a schedule for a lab whose priority is finding that warning.

## Further investigation

Remove four points from a four-dimensional binary affine flat. Compare the intact cube counts when the four missing points form a plane and when they are affinely independent. Prove your counts by inclusion and exclusion or exhaustive enumeration, then ask which pattern you would predict for four missing points in higher dimension.

## Provenance and verification

Atlas Open Mathematics, directed by Albert Tan Sin Hon. Prepared with AI assistance. These exercises were prepared for this programme using established mathematics. The collection makes no claim of first discovery or official contest provenance.

Designed for the Atlas Math Olympiad. Related background on four-point planes appears in Marcus Brinkmann, Classification of Almost Perfect Nonlinear Functions up to Dimension Five (2007), Chapter 3.

The worked arguments support the general conclusions. The executable checks provide separate evidence for specified finite cases. The challenge bands are editorial judgements and have not been calibrated against human contest performance. [Reproduce the checks and inspect their scope](../README.md#verification).

Edition 1.0.0, 2026-11-28. [Edition DOI](https://doi.org/10.5281/zenodo.24620475) · [Project educational licence](../../../LICENSE-CONTENT.md) · [Code licence](../../../LICENSE)

For the four-point characterisation used in the proof, see Marcus Brinkmann, [Classification of Almost Perfect Nonlinear Functions up to Dimension Five](https://www.nds.ruhr-uni-bochum.de/media/nds/veroeffentlichungen/2019/03/18/apn.pdf), Ruhr-Universität Bochum (2007), chapter 3, propositions 3.1 and 3.2.
