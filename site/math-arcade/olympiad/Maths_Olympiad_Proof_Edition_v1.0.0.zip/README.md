# Atlas Open Mathematics: Olympiad proof practice

Open [the problem sheets](research/olympiad/Problem_Sheets.html) in a browser to read or print the exercises without answers. Open [the proof collection](research/olympiad/README.md) to find the complete solutions, further investigations and offline verification commands. Plain Markdown and JSON files can also be read in a text editor.

Atlas Open Mathematics, directed by Albert Tan Sin Hon. Prepared with AI assistance. Edition 1.0.0, 2026-11-28. Original problem text, explanations and diagrams: CC BY 4.0. Executable checks: MIT.

Each entry in SHA256SUMS records the SHA-256 digest of one other file in this archive.
